import gym

gym.logger.set_level(40)
